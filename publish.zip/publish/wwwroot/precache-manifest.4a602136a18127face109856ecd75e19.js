self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "acc51811eb960e01d492a593dd82d3e5",
    "url": "/index.html"
  },
  {
    "revision": "4a64bb7b902e2fe7e289",
    "url": "/static/css/2.57e2a37d.chunk.css"
  },
  {
    "revision": "400126891026b72d9554",
    "url": "/static/css/main.01c2a599.chunk.css"
  },
  {
    "revision": "4a64bb7b902e2fe7e289",
    "url": "/static/js/2.5fcfd291.chunk.js"
  },
  {
    "revision": "a73511fdd0e79fea52c5f42ad1574633",
    "url": "/static/js/2.5fcfd291.chunk.js.LICENSE.txt"
  },
  {
    "revision": "400126891026b72d9554",
    "url": "/static/js/main.97c5dc4f.chunk.js"
  },
  {
    "revision": "efdf6692e5d5af29f2d6",
    "url": "/static/js/runtime-main.fdea7932.js"
  },
  {
    "revision": "c7a33805ffda0d32bd2a9904c8b02750",
    "url": "/static/media/color.c7a33805.png"
  },
  {
    "revision": "3377ac1bee3ec8d9a5963cf49dc0caa9",
    "url": "/static/media/poppins-all-400-italic.3377ac1b.woff"
  },
  {
    "revision": "2b7b1aec0bbda049675f582f71d6d9a3",
    "url": "/static/media/poppins-all-400-normal.2b7b1aec.woff"
  },
  {
    "revision": "0501075a1c312896b2fec10f490f49ac",
    "url": "/static/media/poppins-devanagari-400-italic.0501075a.woff2"
  },
  {
    "revision": "d5e78c53cb0716cfec0b96fe178870f9",
    "url": "/static/media/poppins-devanagari-400-normal.d5e78c53.woff2"
  },
  {
    "revision": "c8844b2518e608504a044c16951c094e",
    "url": "/static/media/poppins-latin-400-italic.c8844b25.woff2"
  },
  {
    "revision": "9ed361bba8488aeb2797b82befda20f1",
    "url": "/static/media/poppins-latin-400-normal.9ed361bb.woff2"
  },
  {
    "revision": "aaefa4cfcaa73c8ab2ba1310939ec9dd",
    "url": "/static/media/poppins-latin-ext-400-italic.aaefa4cf.woff2"
  },
  {
    "revision": "4d1490f32451df75d9cdcccb0c82874c",
    "url": "/static/media/poppins-latin-ext-400-normal.4d1490f3.woff2"
  },
  {
    "revision": "159263bf4976843830365d52d1f94fba",
    "url": "/static/media/primeicons.159263bf.eot"
  },
  {
    "revision": "2e3a6b48408add8bb604d0b4e820a3b5",
    "url": "/static/media/primeicons.2e3a6b48.ttf"
  },
  {
    "revision": "4e915114c908962a6ff2d505c2a4816b",
    "url": "/static/media/primeicons.4e915114.svg"
  },
  {
    "revision": "79432094e4838b36d974b9d8c57d22e2",
    "url": "/static/media/primeicons.79432094.woff"
  }
]);