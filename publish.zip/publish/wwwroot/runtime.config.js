window['configs'] = {
  baseURL: 'http://kkcprofessional-001-site1.etempurl.com/'
};