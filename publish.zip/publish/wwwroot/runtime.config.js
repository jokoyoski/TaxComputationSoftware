window['configs'] = {
  baseURL: 'http://kkc-ps-taxcomputation.com/'
  //baseURL: 'http://localhost:5000/'
};
