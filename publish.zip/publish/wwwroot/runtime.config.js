window['configs'] = {
  // baseURL: 'http://nanoreward-001-site2.etempurl.com/'
  baseURL:'http://kkcprofessional-001-site1.etempurl.com/'
  //baseURL: 'http://localhost:5000/'
};
