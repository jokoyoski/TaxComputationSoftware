window['configs'] = {
  baseURL: 'http://nanoreward-001-site2.etempurl.com/'
};