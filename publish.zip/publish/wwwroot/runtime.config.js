window['configs'] = {
   baseURL: 'https://kkc-ps-taxcomputation.com/'
  //baseURL: 'http://localhost:5000/'
};
